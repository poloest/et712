function fToC(fahrenheit){
    var temp = fahrenheit;
    var celsius = (temp - 32) * 5 / 9;
    var message = temp + '°F is ' + celsius + '°C.'
    console.log(message);
}

fToC(32);
fToC(0);
fToC(90);

console.log("John was born on 1996 and John is 6 feet tall.");
console.log("Mark was born on 1992 and Mark is 5.6 feet tall.");
console.log("Lucas was born on 1976 and Lucas is 6.4 feet tall.");

var name = prompt("Please enter your name: ");

function replaceText(){
    var text = document.getElementById("Title");

    if(name != null && name != ""){
        text.innerHTML = "<h1>" + name + "</h1>";
    }
    else{
        text.innerHTML = "<h1>" + "Assignment 3" + "</h1>";
    }
}

replaceText();
